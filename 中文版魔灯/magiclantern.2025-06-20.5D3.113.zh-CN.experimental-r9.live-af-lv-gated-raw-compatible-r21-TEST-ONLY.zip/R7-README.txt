5D3 Live AF r7 — TEST ONLY

Base package: magiclantern.2025-06-20.5D3.123.zh-CN.experimental-r9.zip

Changes from r6:
- Removed the added experimental Quick AF module (af_quick.mo).
- Fixed repeated centering: initial center-and-focus now runs once only after
  entering a new video Live View session. Canon being busy during that focus
  no longer counts as leaving and re-entering Live View.
- Once the initial focus completes, the AF frame remains under user control.
  Moving it later triggers the existing Live AF behavior after about 0.35 s.

Unchanged safeguards:
- Centering must be confirmed before initial AF; otherwise it is skipped.
- 0.7-second post-focus cooldown remains.
- No automatic AF is triggered while recording.
- Core, all original modules, font, and all other r6 files remain unchanged.

Experimental module. Test without recording first. Do not use during an important shoot.
