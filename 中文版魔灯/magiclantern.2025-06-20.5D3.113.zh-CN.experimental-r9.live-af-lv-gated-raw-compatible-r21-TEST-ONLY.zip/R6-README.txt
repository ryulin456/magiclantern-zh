5D3 AF frame modes r6 — TEST ONLY

Base package: magiclantern.2025-06-20.5D3.123.zh-CN.experimental-r9.zip

Change from r5:
- Live AF has a new enabled-by-default option: when video Live View becomes ready,
  it asks the existing Magic Lantern core to center the Canon Live AF frame,
  verifies the reported frame is centered, then performs one native Canon AF cycle.
- If centering is not confirmed within 1.5 seconds, it skips the initial AF rather
  than focusing at the previous position.

Unchanged from r5:
- After later frame moves, Live AF waits about 0.35 seconds before native AF.
- Quick AF remains at a 0.5-second delay.
- Both modules retain the 0.7-second post-focus cooldown.
- No AF is triggered while recording.
- Core, all original modules, font, and all other r5 files are retained unchanged.

Experimental module. Test without recording first. Do not use during an important shoot.
