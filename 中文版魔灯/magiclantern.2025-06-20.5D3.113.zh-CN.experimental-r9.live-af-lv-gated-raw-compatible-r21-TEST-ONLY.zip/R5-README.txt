5D3 AF frame modes r5 — TEST ONLY

Base package: magiclantern.2025-06-20.5D3.123.zh-CN.experimental-r9.zip

Change from r4:
- Live AF: autofocus starts about 0.35 seconds after the Canon Live AF frame stops moving.

Unchanged from r4:
- Live AF only accepts Canon Live mode (one movable AF frame).
- Quick AF remains at a 0.5-second delay.
- Both modules keep the 0.7-second post-focus cooldown.
- The core, all original modules, font, and all other files are retained unchanged.

Experimental module. Test without recording first. Do not use during an important shoot.
