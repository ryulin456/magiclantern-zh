5D3 AF-frame mode comparison r4 (TEST ONLY)

Live module tuning: only Canon Live AF is accepted (not Quick, face or multi);
the one movable Canon AF frame must settle 0.5 s before focus starts; after one
focus operation the module waits 0.7 s before accepting another frame movement.
Enable only af_live.mo. In Canon Movie mode select Live mode AF, not Quick AF.
