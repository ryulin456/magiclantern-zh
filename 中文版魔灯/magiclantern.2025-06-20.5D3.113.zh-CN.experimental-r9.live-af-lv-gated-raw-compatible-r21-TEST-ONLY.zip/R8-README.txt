5D3 Live AF r8 — TEST ONLY

Base package: magiclantern.2025-06-20.5D3.123.zh-CN.experimental-r9.zip

Change from r7:
- Added the disabled-by-default Live AF option "录制中原生对焦（实验）".
- When explicitly enabled, moving the Canon Live AF frame during H.264 recording
  may send a software half-shutter AF request after the existing 0.35 s delay.
- While recording, the module does not call lens_setup_af or alter Canon's AF
  button assignment. The lens must be in AF and the camera's normal half-shutter
  AF assignment must already be enabled.
- Starting recording is not treated as a new Live View session, so it does not
  re-center the AF frame.

Important: this is an unverified camera-specific experiment. Canon may ignore
the software half-shutter while recording, depending on lens and settings.
Stop immediately if recording stops, the camera becomes unresponsive, or AF
behaves unexpectedly.
